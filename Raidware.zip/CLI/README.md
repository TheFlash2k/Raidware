# Raidware - CLI Version
---

All the source code within this folder will represent the CLI version (which will be like 90% of the code that will be used in the actual backend for this application.

The entire backend will be written in Python and will serve as a framework and will allow multiple developers to even create their own listeners/modules and everything so that it will easily be integrated within the Raidware framework.

